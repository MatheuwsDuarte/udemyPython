import os
import boto3

# Isso vai remover colchetes e espaços caso eles venham da variável de ambiente
AMI = os.environ['AMI'].replace('[', '').replace(']', '').replace("'", "").replace('"', '').strip()
INSTANCE_TYPE = os.environ['INSTANCE_TYPE']
KEY_NAME = os.environ['KEY_NAME']
SUBNET_ID = os.environ['SUBNET_ID']

ec2 = boto3.resource('ec2')


def lambda_handler(event, context):
    print(f"DEBUG: O valor da AMI é: >>>{AMI}<<<")

    instance = ec2.create_instances(
        ImageId=AMI,
        InstanceType=INSTANCE_TYPE,
        KeyName=KEY_NAME,
        SubnetId=SUBNET_ID,
        MaxCount=1,
        MinCount=1
    )

    print("New instance created:", instance[0].id)